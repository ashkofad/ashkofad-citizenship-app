export default function App() {
  return (
    <div style={{ textAlign: 'center' }}>
      <h1>🇨🇦 Canadian Citizenship Practice Test</h1>
      <p>Welcome to the Ashkofad Citizenship App!</p>
    </div>
  );
}